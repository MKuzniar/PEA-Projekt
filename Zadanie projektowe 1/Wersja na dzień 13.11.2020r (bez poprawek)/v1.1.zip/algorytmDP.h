#pragma once

#include <iostream>
#include <vector>

using namespace std;

int algorytmDP(int maska, int aktualne_miasto, int n, vector<int>& v); //rekurencyjna funkcja wyznaczajaca najkrotsza droge miedzy miastami 