#pragma once

#include <iostream>

using namespace std;

long long int read_QPC(); //QueryPerformanceCounter