#pragma once

#include <iostream>
#include <vector>

using namespace std;

void wyswietlMacierz(int n, vector<int>& v); //funkcja wyswietlajaca wprowadzona macierz

void sprawdzDane(int n, vector<int>& v); //funkcja sprawdzajaca poprawnosc wprowadzonych danych - czy na przekatnej i tylko na przekatnej macierzy sa zera